# AGENTS.md — Gestão e Controle · Vilaça Joias

> Cole este arquivo no início de toda conversa sobre o app (geral ou por módulo).
> Cursor: coloque na raiz do repo. Claude: cole como primeira mensagem da sessão.

---

## 1. Identidade do projeto

Sistema web de gestão multimódulo para a rede de joalherias **Grupo Vilaça Joias**
(Juiz de Fora, MG, Brasil). Projeto piloto em produção real com dados reais.

- **Repo GitHub:** `https://github.com/joiasvilaca-web/controle-lojas-`
- **Upload link:** `https://github.com/joiasvilaca-web/controle-lojas-/upload/main`
- **Hosting:** Vercel (frontend estático)
- **Backend:** Supabase — project ID `wxiokmqnjtgbejgoepch`

---

## 2. Stack

| Camada | Tecnologia |
|---|---|
| Frontend | Vanilla HTML + CSS + JavaScript (sem frameworks) |
| Backend / API | Supabase Edge Functions (TypeScript/Deno) |
| Banco de dados | Supabase Postgres |
| Storage | Supabase Storage (bucket `atendimento-midia`) |
| E-mail | Edge Function `send-email-gmail` via Gmail API |
| IA | Gemini API (conta própria do Felipe, quota gratuita) |
| WhatsApp | Evolution API v2.3.7 no Railway (`scintillating-wisdom`) |
| Fotos de produto | Photoroom (primário) + Gemini (fallback) |

**Não usar React, Vue, npm, ou qualquer bundler.** Todo JS é vanilla, sem `import/export` de módulos ES6 (exceto dentro das Edge Functions Deno).

---

## 3. Segurança — NUNCA contornar

- **`db-gateway`** é o único ponto de acesso ao banco. Versão em produção: **v45+**
- RLS ativo em todas as tabelas. Zero `GRANT` para `anon`/`authenticated`
- Funções SQL com `SECURITY DEFINER` têm `EXECUTE` revogado de `public/anon/authenticated`
- O gateway valida sessão (`sessaoValida()`), permissão por módulo e isolamento por loja
- **Nunca acessar tabelas diretamente via anon key** (exceto `gestao_config` leitura básica e legacy)
- Anti-overwrite: `saveConfig` com array vazio de users/lojas retorna HTTP 409
- Tabela protegida `atendimento_segredos`: só service_role

---

## 4. Autenticação e sessões

- Login por **apelido** (ou nome completo se sem apelido) + senha bcrypt
- Servidor gera token de sessão → guardado em `users[].sessoes[]` (até 5 simultâneas)
- Sessão: 12h no servidor, 8h no app (localStorage)
- 6 tentativas erradas → bloqueia usuário (`users[].bloqueado`)
- Desbloquear: botão no DP (só Diretoria)
- Níveis de acesso: `Diretoria` / `Gerente` / `Vendedora` / `Oficina`

---

## 5. Lojas (5 unidades)

| Slug | Nome | Observação |
|---|---|---|
| `loja_mc` | Marechal Center | |
| `loja_jb` | João Beraldo | |
| `loja_jn` | Jardim Norte | |
| `loja_ec` | Ecommerce | |
| `loja_rj` | Reforma Joias | Piloto WhatsApp/Instagram |
| `loja_uc` | Up Case | Parceira externa (só Gravações) |

Cada loja tem cor temática. Login da Up Case abre direto em Gravações.

---

## 6. Arquivos do frontend

| Arquivo | Módulo |
|---|---|
| `index.html` | Shell principal (menu, autenticação, roteamento de módulos via iframe) |
| `vendas.html` | CAIXA › Vendas (PDV) |
| `painel-ordens.html` | Pedido / O.S. |
| `orcamentos.html` | Orçamentos |
| `transferencias-reposicoes.html` | Transferências / Reposições |
| `gravacoes.html` | Gravações (serviço Up Case) |
| `caixa.html` | CAIXA › Resumo do caixa |
| `gastos.html` | Gastos (sub-tela do Caixa) |
| `conciliacao.html` | Conciliação (sub-tela do Caixa) |
| `dashboard.html` | PAINEL › Dashboard (Visão geral com gráficos + relatórios) |
| `ia.html` | Módulo IA (Diretoria/Gerente) |
| `marketing.html` | CAIXA › Aniversário (abas Aniversário + Mala direta, com `?secao=aniversario`). O follow-up de orçamentos foi para a aba Follow-up do `orcamentos.html` |
| `dp.html` | Departamento Pessoal (inclui Funcionários e Perfis de Acesso) |
| `avisos.html` | PAINEL › Avisos (tela inicial pós-login para todos) |
| `atendimento.html` | CHAT: WhatsApp/Instagram + conversas internas na mesma lista + Agenda (tarefas, calendário, minhas vias, assistente) |
| `definir-senha.html` | Página pública de setup de senha (link de convite) |
| `advertencia.html` | Página pública de confirmação de advertência (DP) |
| `insumos.html` | CAIXA › **OFICINA** (cartão; id interno `insumos`): aba Vias (todas as lojas, filtros, leitor de código/câmera, status Oficina pronto, local da peça, observação para a loja, material usado) + Saldos, Lançar, Movimentos, Cadastro de insumos — fala só com a Edge Function `insumos-api` |
| `inventario.html` | CAIXA › **INVENTÁRIO** (cartão; sub `inventario`, iframe `caixa_inventario`, **usa a permissão de Transferências**): relatório de estoque por loja (filtros + CSV/Excel/PDF) e contagem de peças com leitor/câmera — fala só com a Edge Function `inventario-api` |
| `reforma-admin.html` | CAIXA › Reforma — módulo interno (fila de pedidos, orçamento, custódia, Gerar O.S.) |
| `reforma.html` | Página pública do cliente da Reforma (envia fotos, aceita orçamento, acompanha pelo link `?t=TOKEN`) |

**`index.html` (shell) só é editado na conversa APP GERAL.**

---

## 7. Estrutura do shell (index.html)

Grupos de menu com abas em `#shellTopTabs`:

| Grupo | Sub-telas | Permissão base |
|---|---|---|
| **PAINEL** (id `dashboard`) | Dashboard · Avisos · IA (abas) — **Dashboard é a aba principal** (abre nela; quem não tem o módulo `dashboard` abre em Avisos, que é de todos) | Avisos: todos; `dashboard` / `ia` |
| **CAIXA** (id `caixa`, cartões) | Vendas · Pedido · Orçamento · Transferências · Gravações · Resumo do caixa · Gastos · Conciliação · Reforma · Aniversário | por sub-tela: `vendas` / `os` / `orcamentos` / `transferencias` / `gravacoes` / `caixa` / `gastos` / `conciliacao` / `reforma` / `marketing` |
| **CHAT** (id `atendimento`) | — | `atendimento` |
| **CONFIGURAÇÕES** (id `config`) | Cadastro · Departamento pessoal (abas) | `config` / `dp` |

- Padrão de texto (28/out): módulos e cartões em CAIXA ALTA; abas só com a 1ª letra maiúscula e sem emoji (`rotuloAba` no shell normaliza o que os módulos mandam). Aba com rótulo repetido não aparece duas vezes.
- O shell marca o `<html>` de cada módulo com `embedded` (`marcarEmbutido`); `tema.css` esconde o `#lojaFaixa` lá dentro (a loja já aparece no cabeçalho).
- Iframes do CAIXA: `caixa_pdv`, `caixa_os`, `caixa_orc`, `caixa_transf`, `caixa_grav`, `caixa_resumo`, `caixa_gastos`, `caixa_conciliacao`, `caixa_reforma`, `caixa_aniv` (`marketing.html?secao=aniversario`).

- Loja selecionada: `<select id="shellLojaSelect">` ao lado da logo
- Módulos absorvidos mapeados em `MODULOS_ABSORVIDOS` (ids antigos → grupo+sub)
- `irParaModulo(id, {registroId, tab})` é o único jeito de navegar entre módulos

---

## 8. Edge Functions (Supabase)

| Função | Versão prod | Uso |
|---|---|---|
| `db-gateway` | v54 | Gateway central — TODA leitura/escrita do banco |
| `funcionario-acesso` | v19 | Login, convite, troca de senha, sessões |
| `send-email-gmail` | v8 | E-mail automático (sem modal de composição) |
| `ia-chat` | v17 | Chat IA + análise de imagem (Gemini) |
| `gemini-agente` | v11 | Monitoramento IA (roda 1x/dia no Dashboard) |
| `confirmar-leitura-dp` | v6 | Confirmação de advertência (página pública) |
| `confirmar-leitura-gravacao` | v3 | Confirmação de leitura da via (cliente) |
| `get-gravacao-status` | v4 | Status público da via de gravação |
| `atendimento-webhook` | v3 | Recebe eventos WhatsApp (Evolution) e Instagram |
| `atendimento-api` | v15 (painel) | Todas as ops do módulo Atendimento. 29/out: considera a loja extra da sessão (OUTRA LOJA) |
| `upload-foto-drive` | v23 | Upload de fotos para Google Drive |
| `reforma-api` | v11 (painel) | 29/out: considera a loja extra da sessão (OUTRA LOJA). Todas as ops do módulo Reforma (públicas `public*` sem sessão + internas com `senha`) — v2: multi-itens, frete, WhatsApp Evolution |
| `insumos-api` | v5 | Insumos da Oficina (ouro, prata, cobre, pedras): cadastro, Kardex (`insumos_movimentos`), saldos por loja dona × local (loja/oficina), baixa por via (`consumoVia`), estorno; v2: `vias`/`via`/`viaAtualizar` (a Oficina vê vias de todas as lojas e só mexe em status aguardando⇄oficina_pronto, local da peça e observação). Código em `insumos-api.ts` |
| `site-public` | v5 | API pública dos sites (catálogo/frete/pedidos). Canal `vilaca` (padrão) ou `reforma` (`canal:"reforma"`: config na linha `site_config` id `reforma`, só produtos com `site.lojaId='loja_rj'`; o site da Vilaça nunca mostra peças da Reforma). Código em `site-public.ts` |
| `site-admin` | v5 | API do módulo SITE (produtos, pedidos, config). v3: campos `condicao/estado/historia/garantiaDias` do produto e `salvarConfig` com `canal:'reforma'`. Código em `site-admin.ts` |
| `inventario-api` | v4 | 29/out (v4): considera a loja extra da sessão (OUTRA LOJA). Inventário: `init`/`catalogo`/`iniciar`/`abrir`/`poll`/`ler`/`desfazer`/`concluir`/`ajustar`/`recontagem`/`cancelar`. Código em `inventario-api.ts`. Permissão: módulo `transferencias` (ou diretoria/gerente); só diretoria/gerente ajusta estoque; vendedora só vê as lojas dela |
| `cotacoes-mercado` | — | Cotações (não usa sessão) |
| `agenda-tarefas` | v2 | v2: considera a loja extra da sessão (OUTRA LOJA). Agenda do CHAT: tarefas (tabela `agenda_tarefas`), lembretes pro calendário e "Minhas vias". Código em `agenda-tarefas.ts`. Usa `npm:@supabase/supabase-js@2` (o deploy com `jsr:` estava dando timeout) |

Deploy: **`files` param precisa do conteúdo completo com `name: index.ts`** e `verify_jwt: true` (boolean).

Quando uma Edge Function chama outra internamente, incluir **ambos** os headers:
```
Authorization: Bearer ${SERVICE_ROLE_KEY}
apikey: ${SERVICE_ROLE_KEY}
```

---

## 9. Banco de dados — tabelas principais

| Tabela | Descrição |
|---|---|
| `gestao_config` | Config geral (JSONB, id=`config`). Nunca sobrescrever com vazio |
| `clientes_cadastro` | Cadastro unificado de clientes (22k+ registros) |
| `vendas` | Vendas / PDV |
| `ordens_servico` | Pedidos / O.S. |
| `orcamentos` | Orçamentos |
| `dp_registros` | Fichas de RH (Departamento Pessoal) |
| `gravacoes_kv` | KV do módulo Gravações |
| `estoque_movimentos` | Kardex (movimentos de estoque) |
| `atendimento_conversas` | Conversas WhatsApp/Instagram |
| `atendimento_mensagens` | Mensagens individuais |
| `atendimento_segredos` | Segredos protegidos (só service_role) |
| `painel_ordens_kv` | KV do módulo O.S. |
| `ia_memoria` | Memória do módulo IA |
| `reforma_pedidos` | Pedidos de reforma (colunas reais: `numero` bigserial, `token`, `status`, `loja_id`, `telefone_digits` + `payload`) |
| `insumos` | Cadastro de insumos da Oficina (`id`, `payload` {nome, categoria metal/pedra/outro, unidade g/ct/un, teor, origemPedra, dimensoes, peso, quilates, ncm, custoRef}, `ativo`) |
| `insumos_movimentos` | Kardex dos insumos: `insumo_id`, `loja_id` (dona fiscal), `local` loja/oficina, `tipo` COMPRA/ENVIO/RETORNO/CONSUMO/PERDA/AJUSTE/ESTORNO, `quantidade` (com sinal), `valor_unit`, `os_id`, `codigo_via`, `finalidade` servico/fabricacao, `ref_id`, `payload` (por, obs, fiscal da compra, par) |
| `insumos_contagens` | Contagem real da Oficina por metal: `quantidade_real`, `saldo_sistema` (bruto na data), `quebra_padrao_pct` (vigente na data), `acertada`. A quebra padrão global fica em `insumos` id `_config` (`quebraPadraoPct`, padrão 5) |
| `inventarios` | Contagens de estoque (`id`, `loja_id`, `nome`, `status` em_andamento/concluido/cancelado, `cego`, `payload` {itens:[{produtoId, esperado}] = foto do saldo no início, relatorio (congelado ao concluir), ajustes}). RLS, sem GRANT |
| `inventario_leituras` | Cada leitura/digitação da contagem (`seq`, `inventario_id`, `codigo`, `qtd`, `cid` único por inventário = não duplica em reenvio, `por`, `anulada`). A classificação (verde/vermelho) nunca é gravada: é derivada |
| `reforma_config` | Config do módulo Reforma (id=`config`: lojas públicas, endereços, serviços, textos, mensagens WhatsApp) |

**Tabelas KV** têm colunas `key`/`value`. Acesso via `kvGet`/`kvSet` no db-gateway (não anon direto).

**JSONB:** usar `payload->>'campo'` em queries SQL.

**Storage:** buckets privados `atendimento-midia` e `reforma-fotos` (fotos do cliente/custódia da Reforma — sempre via signed URL gerada pela Edge Function, nunca URL pública).

---

## 10. Padrões de código obrigatórios

### Texto
```js
// Maiúscula automática ao salvar
function maiusc(str) {
  return str ? str.toUpperCase() : str;
}
```

### Telefone
```
Formato: (XX) XXXXX-XXXX
DDD separado. 9 dígitos. Valida completo ou vazio.
Fixo: 8 dígitos → (XX) XXXX-XXXX
```

### Carregamento de listas
**Nenhuma lista ou relatório carrega automaticamente ao abrir.**
O filtro começa recolhido. Conteúdo só aparece após o usuário apertar o botão de busca/filtro.

### Numeração de vias
Sequência: `LOJA+NÚMERO+TIPO` (ex: `MC1P`). Via `bumpCodigoViaSequence` no gateway.

### Código de autorização (O.S.)
Quando vendedora sobrescreve data sugerida → aciona fluxo de código de autorização validado em tempo real (Oficina/Diretoria).

---

## 11. Regras de entrega (para Claude e Cursor)

1. **Nunca reescrever arquivo inteiro** sem necessidade — fazer edição cirúrgica no trecho exato
2. **Reclone o repo antes de cada edição** — não confiar em memória/cache
3. **Nunca remover feature não mencionada no pedido**
4. **Avisar antes de codar** se a mudança afetar: schema do banco, roteamento Vercel, outro arquivo não mencionado
5. **Verificar se já existe** antes de reimplementar
6. **Se for só backend** (Edge Function): avisar que não precisa subir nada no GitHub
7. **Validar JS** com `node --check arquivo.html` antes de entregar
8. **Sempre entregar** arquivo completo + link: `https://github.com/joiasvilaca-web/controle-lojas-/upload/main`
9. **Resposta ao Felipe (29/out):** não descrever o que foi implementado. Responder só com o que depende da ação dele para finalizar, ou com falhas/limitações encontradas.

---

## 12. Convenção de conversas (Claude)

Cada conversa é **escopada a um único módulo**:

| Conversa | Escopo |
|---|---|
| `APP GERAL` | Shell index.html, assuntos transversais, novos módulos |
| `APP VENDAS` | vendas.html (PDV) |
| `APP OS` | painel-ordens.html |
| `APP ORCAMENTO` | orcamentos.html |
| `APP TRANSFERENCIAS` | transferencias-reposicoes.html |
| `APP CAIXA` | caixa.html + gastos.html + conciliacao.html |
| `APP GRAVACOES` | gravacoes.html |
| `APP DASHBOARD` | dashboard.html |
| `APP IA` | ia.html |
| `APP MARKETING` | marketing.html |
| `APP DP` | dp.html |
| `APP CADASTRO` | Trecho Cadastro dentro do index.html |
| `APP ATENDIMENTO` | atendimento.html |
| `APP REFORMA` | reforma-admin.html + reforma.html + Edge Function reforma-api |

**Antes de qualquer ação:** verificar se o app foi atualizado em outra conversa paralela (Felipe trabalha em múltiplas conversas ao mesmo tempo).

---

## 13. Pendências em aberto

- [ ] SQL de segurança aguardando aprovação do Felipe: `search_path` fixo nas funções `registrar_movimento_estoque`, `incrementar_via_sequence`, `liberar_via_sequence`, `abrev_para_loja_id`, `temp_sigla_loja`; revogar EXECUTE de `temp_sigla_loja` pro anon; ligar RLS em `clientes_backup_pre_limpeza_20260914` e `vendas_backup_pre_limpeza_20260914`
- [ ] Railway: upgrade pro Hobby pendente (cartão deu erro em 14/set) — trial vence ~12/out
- [x] Chave Evolution API trocada em 30/out (Railway `AUTHENTICATION_API_KEY` + tabela `atendimento_segredos`). **Pendente (Felipe):** apagar o segredo antigo `EVOLUTION_API_KEY` em Supabase › Edge Functions › Secrets (as funções ignoram esse segredo e leem só a tabela)
- [ ] `venda-pg.html` e `pg-mes.html`: deletar manualmente no GitHub
- [ ] NFC-e/NF-e: aguardando certificado A1 + orientação do contador
- [x] Modelo multiloja: implementado em 29/out (ver lição 31)
- [ ] O.S.: migração para o catálogo novo de produtos (hoje usa `produtosOtica` legado)
- [ ] Instagram Atendimento: falta vincular conta da Reforma ao app Meta e gerar token
- [ ] Reforma: Oficina fica com o módulo desligado por padrão (para não aparecer no login da Up Case) — liberar por usuário no DP se a oficina for fazer o check-out
- [x] **Segurança (30/out):** `BOT_TOKEN` e `WEBHOOK_TOKEN` não estão mais no código: ficam em `atendimento_segredos` (chaves `BOT_TOKEN`, `WEBHOOK_TOKEN`, geradas aleatórias), lidos por `tokenInterno()` com cache de 60 s; o pg_cron job 2 (`atendimento-tick`) lê o token da tabela. Tokens antigos recusados (401). `atendimento-diag` e `ig-token-exchange` viraram stub 410. **Ainda no código público (risco baixo):** `VERIFY_TOKEN` do WhatsApp Cloud e `IG_VERIFY_TOKEN` (handshake da Meta; trocar exige mudar no painel da Meta). Ainda no código publicado (não está no repo): `SETUP_TOKEN` (`atendimento-pessoal-setup`) e `CRON_TOKEN` (`atendimento-lembretes-scheduler` + pg_cron job 4)
- [ ] Apagar no painel do Supabase as funções desativadas (devolvem 410): `site-public-teste`, `db-gateway-teste`, `atendimento-diag`, `atendimento-rotacao`, `ig-token-exchange`, `site-import-tray`, e as ~30 `bi4cia-*` (esta última só se Felipe quiser; o bi4cia foi preservado a pedido)
- [ ] Reforma: Felipe já tem contrato com os Correios, mas ainda não configurou as credenciais (usuário do Meu Correios, código de acesso à API do CWS, número do cartão de postagem) em Configurações do módulo — enquanto isso, `frete.provider` fica em `"tabela"` (valores fixos por faixa)

---

## 14. Contatos do ambiente

- **Supabase project:** `wxiokmqnjtgbejgoepch`
- **Railway projeto:** `scintillating-wisdom` (Evolution API)
- **Evolution API URL:** `https://evolution-api-production-951d.up.railway.app`
- **Instância WhatsApp:** `reformajoias` (canal Baileys)
- **Meta App:** "Atendimento Reforma Joia" (id `2230560377789265`)
- **GitHub org:** `joiasvilaca-web`

---

## 15. Lições de 23/set (auditoria geral)

- Edições anteriores apagaram blocos inteiros sem perceber (ex.: commit de 17/set no painel-ordens levou impressão e fotos). **Antes de entregar, rodar a varredura de "função chamada e não definida"** em todo arquivo editado, e comparar a lista de funções com a versão anterior.
- Bibliotecas externas só entram na tela que realmente usa: o SDK do Supabase ficou só onde é chamado (index, painel-ordens, gravacoes, dp); XLSX é carregado sob demanda no index (`carregarXLSX()`).
- `sw.js` v2: bibliotecas de CDN e imagens vêm do cache (stale-while-revalidate); HTML sempre da rede.
- A logo da tela de login virou arquivo (`logo-vilaca.png`), não base64.
- 24/set: `db-gateway` v50 — `selectAll` pagina de 1000 em 1000 (antes o Supabase cortava em 1000 linhas e sumiam os registros mais novos).
- 24/set: o mesmo commit de 17/set (`ba04bba`) também quebrou o `orcamentos.html`: colou uma cópia antiga da tela de Novo Orçamento dentro de `abrirSeletorCliente` e apagou os botões Confirmar/Cancelar do modal de cliente. Restaurado a partir do `87dc6fc`. Ao revisar qualquer arquivo, conferir se as funções fecham onde deveriam (função de 90 linhas que vira 300 é sinal de colagem errada).
- Dashboard: metas gravadas com `mergeConfigKey` na chave `metasMensais` (nunca mais `saveConfig` da config inteira).
- Marketing: aba Orçamentos carrega sob demanda (`carregarOrcamentosSeNecessario`).
- 28/out: Avisos e Dashboard viraram um módulo só, **PAINEL** (id interno continua `dashboard`; `avisos` virou sub-tela `dashboard_avisos`, mapeada em `MODULOS_ABSORVIDOS`). PAINEL não tem tela de cartões: abre sempre em Avisos. Dashboard ganhou a seção **Visão geral** (`renderVisaoGeral`, gráficos em SVG puro, só diretoria/gerente).
- 28/out (2): CUPOM + Caixa + Reforma + Aniversário viraram o módulo CAIXA; Administração → CONFIGURAÇÕES; Atendimento → CHAT. Marketing dividido (Aniversário/Mala direta no CAIXA; follow-up de orçamentos na aba Follow-up do Orçamento, com contador de atrasados). Abas padronizadas e sem repetição; `orcamentos.html` tinha um `@media` sem fechar que deixava a barra escura duplicada aparecer.
- 28/out (2): Chat interno entra na lista principal do CHAT (etiqueta azul "Interno"); o botão Interno só inicia conversa. Agenda virou quadro de tarefas (privada/loja/compartilhada, cores por tipo, classificação), calendário e Minhas vias.
- 28/out (3): Chat interno pode ser finalizado por cada participante (`atendimento_interno_leituras.finalizada_em`; aba Finalizadas; mensagem nova reabre). `atendimento-chat` v3, código em `atendimento-chat.ts`. Barra lateral: abre ao passar o mouse (classe `.aberta`, empurra o conteúdo), não recolhe ao clicar, só quando o mouse sai pelo lado do conteúdo; itens na mesma altura aberta/fechada. Pop-ups não fecham mais ao clicar fora (só pelos botões).
- 28/out (4): **Grupo Vilaça** — conversa coletiva fixa no topo do CHAT (chave `g:vilaca`, `destino_tipo` `grupo`, todos veem, não finaliza). `atendimento-chat` v4. Mensagem interna toca um aviso curto estilo WhatsApp (`tocarSomInterno`); enquanto o CHAT não foi aberto, o shell consulta o `atendimento-chat` a cada 15s (`pollChatInternoShell`) e avisa em qualquer módulo. O sino 🔔 do CHAT (`atd_aviso`) liga/desliga o som.
- 28/out (5): Chat interno aceita foto e arquivo (📎, colar imagem ou arrastar; até 15 MB). Arquivo vai pro bucket privado `atendimento-midia`, pasta `interno/<chave>/`; colunas `anexo_path/anexo_tipo/anexo_nome/anexo_tamanho` em `atendimento_interno`; link temporário pela op `anexoUrl` (`atendimento-chat` v5).
- 28/out (6): a tabela `atendimento_interno` tinha CHECK em `destino_tipo` (só pessoa/departamento); liberado `grupo` (migração `chat_interno_tipo_grupo`). Lição: testar o INSERT real no banco, não só a tela com dados simulados. `atendimento-chat` v7 devolve o erro do banco em texto.
- 28/out (7): **padrão único de abas** (`tema.css`, classe `.abas-std` e as antigas `.mini-tabs` / `.abas` / `.ag-abas` / `.filtros-abas`): texto só com a 1ª letra maiúscula, sem emoji, ativa com fundo azul claro + barra grossa — igual às abas do topo do shell (`.tabs-line` e o 2º nível `.tabs-seg`, que deixou de ser "pílula" preenchida). Não criar CSS de abas novo nos módulos: usar `.abas-std`. Gravações escondia mal a barra escura própria dentro do app (agora `html.embedded header.topbar{display:none}`).
- 29/out: **Clientes** ganharam `observacoes` (texto) e `tags` (lista de ids). A lista de tags fica em `config.tagsClientes` `[{id,nome,cor}]` (salva com `configSave()` no Cadastro; só quem tem o módulo `config` cria/edita/exclui; renomear vale pra todos os clientes). Cadastro › Clientes: filtro por tag, busca por nome de tag, botão "Gerenciar tags"; mesclar duplicados junta observações e tags.
- 29/out (2): **Tags** são criadas/editadas/excluídas no botão "Tags" da tela Cadastro › Clientes (sem aba própria); a lista de clientes abre sozinha, 50 por página; no cadastro do cliente só se marca. **Bolinhas de loja** (`cliente-lojas.js`, `window.ClienteLojas`): cor + sigla da loja onde o cliente já teve venda, orçamento ou O.S. (vínculo por telefone, senão nome, pois os registros não guardam `clienteId`); aparece em Cadastro › Clientes e nos seletores de cliente de Vendas, Orçamento e O.S.
- 29/out (3): **Tag MARKETING OFF** (`marketing-off.js`, `window.MarketingOff`): antes de qualquer envio de WhatsApp/e-mail a cliente com essa tag (nome da tag, sem diferenciar maiúsculas/acentos), abre pop-up "Enviar mesmo assim / Cancelar"; mala direta pergunta uma vez (enviar todos / pular restritos / cancelar). Vale em Aniversário, Mala direta, Follow-up, Orçamento, Pedido/O.S., Gravações e Reforma; **não** vale no CHAT. Rede de segurança: links `wa.me` de qualquer tela que carregue o script passam pela checagem. Novo módulo que envie mensagem a cliente deve carregar o script e chamar `await MarketingOff.permitir({telefone,nome})` antes do envio.
- 29/out (4): **Fiscal — fase 1 (reforma tributária)**, só campos opcionais, nada emite nota. Produto › aba Fiscal: `origem`, `cfopSaida`, `cstIbsCbs`, `cClassTrib`, `regimeItem` (novo/usado), `unidadeTributavel`, `exTipi`, `cest`. Tipos de ordem **não** têm campos fiscais (só controle de agenda — removidos a pedido em 29/out). Formas de pagamento: `tPag`, `cnpjCredenciadora`. Lojas: `nomeFantasia`, `regimeTributario` (simples/simplesExcesso/normal/mei), `porte`, `cnaePrincipal`, `inicioAtividade`, `codigoMunicipioIbge`, `inscricaoMunicipal`, `documentosFiscais`, `serieNfe`, `serieNfce`, `situacaoCadastral`. Clientes: `tipoPessoa`, `cnpj`, `indIE`, `inscricaoEstadual`, `codigoMunicipioIbge` (preenche pelo CEP). Dados das lojas gravados direto em `gestao_config` a partir da consulta SEFAZ-MG (backup em `gestao_config` id `backup_lojas_pre_fiscal_20261029`). Reforma Joias (`loja_rj`) usa os dados do Ecommerce, sem CNPJ, nome e IE; Up Case sem dados fiscais. **Ecommerce consta "Bloqueado como Destinatário na UF"** e é Regime Normal (as demais, Simples; Marechal Center sem regime informado). CST IBS/CBS e cClassTrib ficam em branco até o contador confirmar. Certificado A1 e CSC nunca entram em `config`.
- 29/out (5): preenchimento fiscal sugerido (a confirmar com o contador): produtos `cstIbsCbs 000` / `cClassTrib 000001` / `regimeItem novo`, `origem 0` e NCM (Ouro 71131900, Prata 71131100) nos 491 produtos existentes (backup `produtos_estoque_backup_fiscal_20261029`); relógios ficaram sem NCM (depende do mostrador) e sem origem; `cfopSaida` e NBS em branco. Tipos de ordem: SERVIÇO com item LC 116 14.01. Pelas fontes consultadas, Simples (CRT 1) só passa a ser obrigado a informar IBS/CBS em 2027.
- 29/out (6): **Perfil fiscal por Tipo** (Fator › Venda, `config.fator.tiposVenda[].fiscal` = `{ncm, origem, cfopSaida, cstIbsCbs, cClassTrib, regimeItem}`; padrões em `fiscalPadraoTipo`). Ao escolher/criar o Tipo no produto, `sincronizarFiscalTipo` preenche esses campos só se estiverem vazios ou com o último valor automático; o que foi digitado à mão não é sobrescrito. Não mexe no CFOP de entrada (continua `cfopPadrao`).
- 29/out (7): **Compartilhar cadastros** (botão 📤 nas linhas de Clientes, Lojas e Fornecedores em Cadastro; `abrirCompartilhar` + `textoCompartilhar*` no index.html): modal com texto editável, WhatsApp (número opcional) e e-mail (via `send-email-gmail`) ou copiar. Não vai observações, tags, crédito, fator do fornecedor; contas bancárias da loja só se marcar a opção.
- 29/out (8): **Grupos de tipos de ordem** (`config.gruposTipoOrdem [{id,nome,maxPorDia,prazoMinimoDias}]`, `tiposServico[].grupoId`): tipos do mesmo grupo dividem as vagas por dia (soma) e o prazo. Grupo `fabricacao` = 10 tipos "<CATEGORIA> <OURO|PRATA> PERSONALIZADO / FABRICAÇÃO" (ANEL, PINGENTE, PULSEIRA, CORDÃO, BRINCO) com NCM, CFOP 5.101, origem 0 e CST 000/cClassTrib 000001; prazo e máx. editados no cartão do grupo (copiados para cada tipo). `painel-ordens.html`: `idsDoMesmoGrupo` + `checkSlot` somam o grupo e a agenda mostra um chip por grupo. **Pendente:** `reforma-api` (`sugerirData`) ainda conta vagas por tipo isolado. Backup: `gestao_config` id `backup_tipos_ordem_20261029`.
- 29/out (9): grupo de tipos de ordem `alianca` ("ALIANÇA PERSONALIZADO / FABRICAÇÃO"): `st_lente_simples` (id antigo, renomeado para ALIANÇA OURO ...) e `st_alianca_prata`, prazo 7 / máx. 1 por dia somados. Só dados em `gestao_config`; nenhum arquivo de código mudou.
- 29/out (10): os grupos de tipos de ordem foram **desativados a pedido** (`gruposTipoOrdem` vazio): cada tipo tem prazo e máx./dia próprios; ALIANÇA e SERVIÇO voltaram como eram. O suporte a grupos continua no código (cartão do grupo, soma de vagas em `checkSlot`) mas só aparece se existir grupo.
- 29/out (11): **Fator** e **Tipos de ordem** deixaram de ser abas/cartões do Cadastro e viraram botões no topo de Cadastro › Produto (`abrirSubtelaProduto`, com "← Voltar para Produtos"). As permissões continuam as das abas `fator` e `tiposOrdem` (DP › perfis, `podeSubtelaProduto`).
- 29/out (12): grupo de tipos de ordem `agenda` ("PRODUÇÃO", `prazoIndividual:true`): os 8 tipos atuais (ALIANÇA/SERVIÇO/FABRICACAO × SEM/COM CRAVACAO, RELOGIO ASSISTENCIA AUTORIZADA/JUIZ DE FORA) dividem a MESMA quantidade por dia (máx. 10, soma), cada um com o próprio prazo. Grupo com `prazoIndividual` só propaga `maxPorDia`. Backup: `gestao_config` id `backup_tipos_ordem_pre_agenda_unica_20261029`.
- 29/out (13): Tipos de ordem sem dados fiscais (UI e dados removidos). **Cuidado:** uma tela do Cadastro aberta antes de uma alteração feita direto no banco e depois salva sobrescreve a config inteira (já apagou o grupo `agenda` uma vez); depois de mexer em `gestao_config` por SQL, pedir F5 a todos.
- 29/out (14): as abas **Status de Orçamento** e **Mensagens** do Cadastro viraram uma só, "Status e Mensagens" (`renderStatusMensagensTab`, id `statusOrcamento`), com duas subabas (`.abas-std`). As permissões continuam separadas (`abas.statusOrcamento` e `abas.mensagens` em DP › perfis); a aba aparece se qualquer uma estiver liberada.
- 29/out (15): **Oficina = unidade interna + Insumos.** `loja_of` tem `interna:true` (checkbox em Cadastro › Lojas, chip "UNIDADE INTERNA"); unidade interna some dos seletores de loja de Vendas, Pedido (loja da O.S.), Orçamento e Caixa, mas continua com usuários, dashboard, agenda e autorizações. A Oficina não tem CNPJ: **os insumos pertencem à loja que comprou** e ficam "em poder da Oficina" (`local:'oficina'`). Módulo CAIXA › **INSUMOS** (`insumos.html`, sub `insumos`, iframe `caixa_insumos`, permissão `insumos` com abas `saldos`/`movimentos`/`cadastro`/`baixaVia` em `MODULOS_APP` e nos 3 blocos de `permissoesPadrao` de index.html e dp.html; padrão: diretoria/gerente tudo, oficina saldos + baixaVia, vendedora desligado). Na via (painel-ordens, modal completo e modal da Oficina) o bloco **"Material da Oficina usado nesta via"** (`mountInsumosVia`) lança a saída (serviço ou fabricação) do saldo da **loja da via** em poder da Oficina, valorada pelo custo médio das compras — base para separar material (venda) e mão de obra (serviço) na nota futura. Saldo insuficiente pede confirmação (fica negativo). Nada é apagado: corrigir = estornar. Tabelas com RLS e sem GRANT; só a Edge Function `insumos-api` acessa (permissões conferidas no servidor).
- 29/out (16): **Status `oficina_pronto`** ("Oficina pronto") nas O.S.: a Oficina terminou; a loja confere e marca Pronto. Em painel-ordens (STATUS, `statusLabel`, cores azul, selects e filtro), dashboard (filtro) e acompanhar.html (para o cliente continua "Aguardando"). Não conta vaga na agenda (só `aguardando` conta). O bloco de material saiu do modal da via no Pedido e foi para o cartão **OFICINA** (`insumos.html`, aba Vias): lista com filtros, leitor (campo com Enter — leitor USB/Bluetooth — ou câmera via `BarcodeDetector`), painel da via com status, local da peça (loja/fabrica), observação "[OFICINA] …" que entra em `observacoes` da O.S. (com "avisar a loja" = `notificarPara` das vendedoras/gerentes da loja da via, aparece nos alertas do Pedido) e material usado. Permissão nova aba `vias` no módulo `insumos` (nome "CAIXA › Oficina (vias e insumos)"). Gravação da O.S. pela `insumos-api` com service role (a Oficina não tem lojas no usuário, o db-gateway esconderia as vias), limitada aos campos acima; histórico em `payload.historicoOficina`.
- 29/out (17): Status **`pendencia`** ("Pendência", laranja) nas O.S. — a Oficina parou por um problema (observação obrigatória). No cartão OFICINA a via só pode ir para **Oficina pronto** ou **Pendência** (rádio); sem campo de local (a peça está sempre na Oficina); saída de material com **Ouro 18K como padrão**; serviço × fabricação é **fixo pelo tipo da via** (`finalidadeDoTipo`: nome com SERVI/RELOG/GRAVA/CONSERT = serviço, o resto = fabricação — calculado no servidor); um botão **"Salvar e finalizar"** grava material + status + observação de uma vez. `insumos-api` v3. Para o cliente (acompanhar.html), pendência e oficina pronto aparecem como "Aguardando".
- 29/out (18): Status **`enviado_fabrica`** ("Enviado p/ fábrica", roxo): a via está na Oficina em processo. Rótulo de `oficina_pronto` passou a ser **"Fábrica pronto"** (id não mudou). Fluxo: aguardando → enviado_fabrica (loja; marcar o status na lista ou o botão "Enviar para a fábrica" da localização já troca o outro) → pendencia / oficina_pronto (Oficina) → pronto/entregue (loja). O cartão OFICINA lista só enviado_fabrica, pendencia e oficina_pronto. Vagas da agenda: `STATUS_OCUPA_VAGA` = aguardando, enviado_fabrica e pendencia. `insumos-api` v4. Para o cliente, os três aparecem como "Aguardando".
- 29/out (19): Saldos do cartão OFICINA: coluna **Oficina geral** (soma das lojas) em **bruto** e **com quebra** (bruto × (1 − quebra padrão%)); quebra padrão editável (`salvarConfig`, 5%). **Contagem real** (`contar`/`contagens`/`acertarContagem`): compara real × bruto × esperado com quebra e mostra a quebra real (g e %) × padrão; "Acertar saldos" (só Diretoria/Gerente, só a contagem mais recente e se o saldo não mudou) lança PERDA proporcional entre as lojas (ou AJUSTE se sobrou). Só metais. `insumos-api` v5.
- 29/out (20): **Site Reforma Joias** (`site-reforma/`: index.html + assets, projeto Vercel próprio com Root Directory `site-reforma`; identidade papel/verde/cobre, peças únicas com carimbo de condição, páginas História, Garantia, Devolução (só devolução, sem troca), Peças usadas, Envio, Privacidade). Usa `site-public` com `canal:"reforma"`. Admin em SITE › Produtos (loja que vende = Reforma Joias + condição/estado/história) e SITE › Configurações › Site Reforma Joias (razão social/CNPJ aparecem no rodapé quando preenchidos — exigência do Decreto 7.962/2013 para vender online). Pedidos entram em `site_pedidos` com `loja_id loja_rj` e `pagamento.canal`. `reforma.html`/`reforma-admin.html` agora dizem Reforma Joias. Pendente: `reforma-api` ainda manda e-mail com remetente "Vilaça Joias" (precisa redeploy).
- 29/out (21): **SEO dos sites.** O código publicado do site da Vilaça agora vive em `site-vilaca/` (o `site-vilaca-codigo.zip` está velho; não usar). O projeto Vercel `vilaca-site` **não** é ligado ao Git: publicar com `create_deployment` (arquivos inline + `sha`/`size` dos que não mudaram), primeiro como prévia, testar, depois redeploy com `target: production` (o `promote` de prévia dá 422). O site da Reforma (`site-reforma/`, projeto Vercel `controle-lojas-`, endereço `controle-lojas-rho.vercel.app`) publica sozinho a cada push. Nos dois: `api/pagina.js` (função Vercel) entrega `/p/...` e `/c/...` já montadas no servidor com título, descrição, `og:image` (foto da peça na prévia do WhatsApp), canonical e JSON-LD (`Product`/`Offer` com `itemCondition` — Reforma = usada/recondicionada —, `BreadcrumbList`, `ItemList`); se a API falhar, devolve o `index.html` normal sem cache. `api/sitemap.js` gera `/sitemap.xml` do catálogo. `robots.txt` (bloqueia `/finalizar`, `/pedido/`, `/busca`, aponta o sitemap) e `llms.txt`. `index.html` com JSON-LD da empresa/lojas. **Se trocar o domínio**, atualizar `base` em `api/pagina.js`, `api/sitemap.js`, `SITE_URL` no app.js da Reforma, `robots.txt`, `llms.txt` e o JSON-LD do `index.html`. `site-public` v4: carrega só produtos publicados e só os campos usados, cache com atualização em segundo plano (respostas idênticas à v3, conferidas uma a uma). Sobrou a função `site-public-teste` (cópia usada no teste; pode apagar no painel do Supabase).
- 29/out (22): SITE › Configurações abre em **dois cartões** (Vilaça Joias e Reforma Joias, `SITES_CFG` em site.html); cada um abre o formulário completo do próprio site (`renderFormSite`, salva com `salvarConfig` — Reforma com `canal:'reforma'`). Só a Vilaça tem "Lojas que vendem" e "Padrão das fotos" (o tratamento de foto usa a config da Vilaça para os dois); só a Reforma tem razão social/CNPJ e garantia padrão.
- 29/out (23): **Reformar minha joia** nos dois sites: página `/reformar` (explicativo em 6 passos + dicas de foto), item no menu e no rodapé e faixa na página inicial com botões "Reformar minha joia" e "Como funciona". O pedido é feito no `reforma.html` com `?marca=vilaca` (cores e nome da Vilaça, só lojas MC/JB/JN com nome amigável) ou `?marca=reforma` (só loja_rj). No acompanhamento (`?t=`) sem `marca`, a marca vem da loja de entrega/retirada do pedido; o link gerado no fim do pedido já leva `&marca=vilaca`. Os links que o painel da Reforma manda pelo WhatsApp não levam a marca (pedido só por Correios abre com a cara da Reforma).
- 29/out (24): **Várias lojas por produto no site.** `produto.site.lojaIds` (lista) e `site.lojasAuto` (automático = lojas com estoque > 0); `site.lojaId` continua como 1ª loja (compatibilidade). `site-public` v5: `lojasMarcadas()` decide em qual site a peça aparece (Reforma se tiver `loja_rj`; Vilaça se tiver outra loja) e a venda sai pela loja marcada com mais estoque; automático sem estoque some dos dois sites. Cadastro › Produto ganhou a aba **Site e marketplaces** (mostrar no site, lojas automático/escolher, marketplaces `site.marketplaces` = mercadolivre/shopee/tiktok/amazon — só fica guardado, não há integração com as contas ainda). SITE › Produtos usa as mesmas caixas. `site-admin` v4 aceita `lojaIds/lojasAuto/marketplaces`. Já existia o gatilho `trg_produtos_preserva_site` no banco (se o Cadastro salvar sem `site`/`marketplaces`, mantém os antigos).
- 29/out (25): **Lançamentos › Folha de PG — nova divisão do salário.** Total do mês = máx(mínimo da empresa R$ 2.500, vendas × fator) (gerentes também; o fixo da Amanda não é ajustado e gera aviso). O total é preenchido em sequência até acabar: salário base (piso CCT comércio JF, 1.730) → VR 500 → dia extra 128 (Jardim Norte + Larissa; editável por pessoa) → comissão 10% de (total − VR) → DSR (regra do calendário) → assiduidade 10% da sobra → H. extra 10% da sobra → prêmio = resto. Por fora: vale-transporte = passagem (3,75) × passagens/dia (2) × dias seg.–sáb. sem feriados (editável por pessoa) e plano dental 22,50. Todos os valores ficam em "Regras de divisão". `lancamentos-api` v9 (código em `lancamentos-api.ts`, que estava desatualizado no repo).
- 29/out (26): Folha de PG (2): VT e plano dental **somam por fora** (não entram na divisão). Quatro totais: **Total base** (verbas), **Total bruto** (+ VT + dental), **Total líquido** (− vale adiantamento, padrão 500 por pessoa), **Total líquido descontos** (− INSS e IRRF pelas tabelas 2026 — INSS sem prêmio/VR/VT/dental, IRRF sem VR/VT/dental com a redução até 5 mil/7.350 —, desconto VT até 6% do salário base, outros descontos; dependentes IR por pessoa). Toda verba pode ser digitada à mão (`pessoas[n].man`, campo amarelo; apagar volta ao automático): as verbas automáticas se ajustam e o total do mês se mantém. **SILVANO** = fixo 3.000 + 0,5% de cada categoria (aliança, fabricação, serviço) do fechamento de todas as lojas (`categ`); **SAYMON** fixo 2.300, **KAUA** fixo 2.500 (fixos não sobem para o mínimo). Botão **Exportar folha** gera `.xlsx` (abas Folha e Regras; SheetJS do cdnjs sob demanda). `lancamentos-api` v10.
- 29/out (27): **Inventário** (CAIXA › INVENTÁRIO, `inventario.html` + `inventario-api` v3, tabelas `inventarios` e `inventario_leituras`). Abre no relatório geral de estoque (carrega sozinho, a pedido) com filtros e exportação; **Iniciar contagem** → loja + categorias + produtos (só os que têm estoque na loja; produto do tipo "Serviço" nunca entra — tem saldo fictício). Leitor USB/teclado (Enter) ou câmera; `3*PRD000007` conta 3; só número vira `PRD` + 6 dígitos. Selo verde "Verificado" ou vermelho "Não verificado" + motivo (leitura a mais, vendido/sem saldo, em outra loja, fora da seleção, não cadastrado, serviço). Salva a cada leitura (fila com reenvio, funciona com mais de um aparelho); "Salvar e sair" retoma depois; **contagem cega** opcional; **Concluir** gera o relatório de acertos e falhas (acuracidade, faltas/sobras em unidades e R$, movimentação durante a contagem), exportável (CSV/Excel/PDF); diretoria/gerente pode **Ajustar estoque** (AJUSTE_INVENTARIO no Kardex, uma vez por produto) e **Recontar divergências**. O relatório usa o saldo de NO MOMENTO de concluir; o saldo do início fica guardado só para sinalizar movimentação. Não altera estoque sozinho.
- 29/out (28): limpeza a pedido do Felipe: estoques negativos zerados via `registrar_movimento_estoque` (AJUSTE_INVENTARIO); os 4 backups de clientes (`clientes_*backup*`, ~78 mil linhas) esvaziados — a base atual tem 36 clientes; a rotina `bi4cia-aniversario-cron` foi **pausada** (não apagada) e as 45 tabelas `bi4cia_*`/`parental_*` (outro sistema no mesmo projeto Supabase) foram **mantidas**.
- 29/out (29): **Recorte quadrado de foto de produto** (`recorte-foto.js`, `window.RecorteFoto.abrir({fonte,titulo})` → JPEG quadrado até 1600 px, ou `null` se cancelar; arrastar, zoom, "Preencher" / "Caber inteira" com bordas brancas, girar 90°, aviso se < 700 px). Ligado em: Cadastro › Produto › Fotos (recorte obrigatório ao anexar, antes do tratamento; botão ✂ em cada foto já anexada troca a imagem e apaga a versão tratada do site) e SITE › produto › Fotos (botão "Recortar": `site-admin` v5, op `recortarFoto` grava em `site-produtos/recortes/…`, vira `fotos[].siteUrl` + `recorteUrl`; "Tratar" passa a tratar o recorte; "Usar original" desfaz os dois). Só funciona em foto cujo endereço permite CORS (o bucket `site-produtos` permite; foto de outro endereço pede para anexar de novo). Fotos de O.S., Reforma, DP, Gravações e Chat **não** têm recorte (não vão para o site).
- 29/out (30): **Todo popup tem "×" no topo e "Fechar" no rodapé** (`modal-x.js`, incluído no fim do `<body>` de cada tela com popup; nada a fazer ao criar um popup novo). Os dois fecham SEM salvar e fazem a mesma coisa: acionam o botão Cancelar / Fechar / Voltar / Não / Entendi / OK / Continuar que o popup já tem (texto exato — "Fechar venda", "Cancelar pedido" etc. nunca são acionados); se não houver nenhum, chamam `closeModal`/`fecharModal` ou escondem o popup. O botão "Fechar" do rodapé só é criado se o popup não tiver botão de fechar; o "×" não é criado se o popup já tem um ✕ próprio. Reconhece fundos `.modal-overlay`, `.modal-bg`, `.gerente-alert-overlay`, `.pwd-overlay`, `#modal`, `#rfOverlay`. Continua sem fechar por clique fora ou ESC. Para marcar qual botão é o "fechar" de um popup novo, use o atributo `data-fechar`.
- 29/out (31): **Loja fixa por usuário + "OUTRA LOJA".** Cada pessoa entra na loja configurada no DP (Funcionário › Acesso › **Loja de trabalho**, um campo só, `users[].lojas = [loja]`); nem a diretoria transita mais entre todas. No cabeçalho fica só o balão colorido com a sigla (sem seletor). Para operar noutra loja: CAIXA › cartão **OUTRA LOJA** → escolhe a loja e digita a senha de um gerente/diretor → `db-gateway` v51 op `entrarOutraLoja` grava `users[].sessoes[].lojaExtra {id, ate (máx. 4 h), aprovadoPor}` **só nessa sessão** (as lojas efetivas = próprias + extra; some ao sair/`voltarMinhaLoja`/expirar). Barra vermelha no topo ("operando na loja X"), balão em vermelho, e **10 min sem movimento desloga** (20 min na loja própria). 5 senhas erradas bloqueiam o usuário (DP desbloqueia). Tudo registrado em `loja_acessos_log` (entrou/voltou/senha_errada/bloqueado, quem, loja, aprovado por). `validarSessao`/`login` devolvem `user.lojaExtra` (recarregar a página mantém a barra). **Transição:** quem tem 2+ lojas no DP continua com seletor entre as DELE; diretoria SEM loja definida continua escolhendo entre todas até o DP ser configurado (a maioria dos usuários ainda tem as 5 lojas liberadas — configurar no DP). Módulos com servidor próprio também respeitam a loja extra (`lojasDaSessao` em reforma-api, atendimento-api, atendimento-extra v5, agenda-tarefas, inventario-api; insumos-api, atendimento-chat, atendimento-bot e estoque-api não filtram pelas lojas do próprio usuário). Funções antigas `db-gateway-v49.ts`/`-v50.ts`/`db-gateway.ts` ficam só de histórico; a atual é `db-gateway-v51.ts`. Função `db-gateway-teste` é uma cópia desativada (410) — apagar no painel.
- 29/out (32): **Repaginação geral — "Sistema visual 2" (azul-petróleo refinado, claro + escuro).** Regras completas em `DESIGN.md` (tokens, tipografia, componentes, proibições) e contexto em `PRODUCT.md`. Arquivos centrais: `tema.css` (tokens `--t-*` claro/escuro + aparência de botões, campos, tabelas, selos, popups, toasts), `tema.js` (no `<head>`; preferência `localStorage.vilaca_tema` = claro/escuro/auto; botão sol/lua/monitor na barra lateral do shell; todas as telas abertas mudam juntas), `icones.js` (`Icone('nome',{tam,titulo})` — SVG; botões só de ícone com `.btn-icone`, destrutivo `.btn-icone.perigo`), `formato.js` (`Fmt.brl`, `Fmt.data`, `Fmt.dataHora`, `Fmt.relativo`, `Fmt.tel`…). Toda tela interna tem `<html lang="pt-BR" data-ds>` + `tema.js`: o sistema manda nas cores mesmo com `:root` próprio da tela. **Tela nova:** usar só variáveis (nunca hex no CSS/templates — o escuro depende disso), ícones em vez de emoji, `Fmt.brl` em todo valor exibido (o formato gravado não muda), uma só `.btn-accent` por área, tabela vira cartões ≤760px, estados carregando/vazio/erro, popup com ação principal à direita no rodapé. O seletor de campos do `tema.css` tem especificidade alta: CSS de campo da tela pode precisar de `!important` pontual. Cuidado com `modal-x.js`: o × aciona o primeiro botão com texto exato Cancelar/Fechar/Voltar/Não/OK… — não dê esses textos a botões que fazem outra coisa; `data-fechar` marca o botão de fechar (e esconde o × extra). Telas repaginadas: shell (login, barra lateral, botão de tema, Cadastro), Avisos, Vendas, Pedido/O.S., Orçamento, CHAT, Resumo do caixa, Gastos (abas Lançamentos/Agenda), Conciliação, Dashboard (abas por assunto, metas num popup), Transferências, Gravações, DP, Oficina, Inventário, Reforma, Aniversário/Mala direta, Lançamentos, SITE. Correções de quebra feitas junto: Vendas trava o "Lançar venda" contra clique duplo; DP salva o apelido editado na ficha e confirma antes de remover acesso/excluir registro; Cadastro confirma antes de excluir loja/produto/fornecedor/forma de pagamento e corrigiu colunas CPF/Lojas trocadas; Gravações: × do popup Ver volta a fechar. Valor negativo aparece como "−R$ 10,00".
- 30/out: **Celular.** (1) O teclado só abre quando a pessoa toca num campo de digitar: em aparelho de toque, `tema.js` ignora `focus()`/`select()`/autofocus feitos pelo código em campos de texto (a causa era o `scannerInput` do shell, que recebia foco a cada toque fora de campo, feito para o leitor USB do computador; nos módulos, os "foco no primeiro campo" ao abrir). Toque direto no campo, Enter que pula de campo e devolução de foco logo depois de digitar continuam valendo; no computador nada muda. Detecção: ponteiro principal por toque, ou tela pequena (menor lado ≤ 600 px) com toque. Consequência: popups que antes abriam com o campo já selecionado (senha da gerência, leitor da Oficina/Inventário) pedem um toque no campo; leitor Bluetooth no celular não tem mais onde digitar sozinho. (2) **Sem barra de baixo no celular** (removida a pedido, 30/out): o menu dos módulos abre pelas três barras (`#btnToggleSidebar`) no canto superior esquerdo do cabeçalho, ao lado do Voltar; abre a gaveta lateral.
- 30/out (2): **Chaves e segredos.** Padrão: segredo interno nunca vai escrito no código (repo é público): vai em `atendimento_segredos` e a função lê com cache curto (`tokenInterno`/`segredos()`, TTL 60 s — sem TTL, função "quente" como `atendimento-extra`, que roda todo minuto, nunca enxergaria uma troca). A chave da Evolution é lida **só da tabela** em atendimento-api/-bot/-extra/-ia/-webhook e reforma-api (o segredo de ambiente `EVOLUTION_API_KEY` é ignorado por elas; `bi4cia-aniversario` testa env e tabela e usa a que a Evolution aceitar). Para trocar de novo a chave da Evolution: gerar valor, Railway `AUTHENTICATION_API_KEY` (set-variables com `skipDeploys` + `redeploy` do deploy atual, **o serviço usa imagem `evolution-api:latest` sem versão fixa**: `redeploy` reaproveita a imagem, mudar variável sem `skipDeploys` pode baixar versão nova), atualizar `atendimento_segredos.EVOLUTION_API_KEY`, conferir `fetchInstances`. O webhook da instância `reformajoias` aponta para `atendimento-webhook?t=<WEBHOOK_TOKEN>`; trocar o `WEBHOOK_TOKEN` exige atualizar a URL do webhook na Evolution (`/webhook/set/{instancia}`, preservando os eventos). `atendimento-api` (criar instância) usa o token da tabela.
- 30/out (3): **Funções de acesso** (DP › aba **Funções**, antes "Perfil de acesso"; só Diretoria). Em vez de um perfil por usuário, existem funções reutilizáveis em `config.funcoesAcesso [{id,nome,nivelBase,sistema,descricao,permissoes}]` (4 do sistema: Diretoria/Gerente/Vendedora/Oficina + as que a Diretoria criar, duplicar, editar, excluir; módulos agrupados PAINEL/CAIXA/CHAT/CONFIGURAÇÕES com marcar tudo/limpar por grupo). Cada `users[]` guarda `funcaoId` e `ajustes` (diferença para a função, criada pelo botão **Personalizar** na ficha › Acesso; "Restaurar padrão da função" zera). `u.nivel` = `nivelBase` da função; as permissões efetivas continuam materializadas em `users[].permissoes` (quem segue o padrão mantém `null`) — o gateway e os módulos não mudaram. Mudar a função de uma função reaplica a todos (`reaplicarFuncao`), preservando os ajustes. Ficha e "Adicionar funcionário"/"Enviar link de cadastro" ganharam o seletor de função (o antigo campo "Função" virou "Cargo"). Migração não destrutiva (`garantirFuncoes`): semeia as 4 funções e converte permissões personalizadas existentes em `ajustes`; usuário sem função aparece em "Acessos sem função". O antigo `openAcessoModal` ficou definido mas sem uso. **Trava no servidor (`db-gateway` v52):** `saveConfig` de quem não é Diretoria preserva `nivel/lojas/permissoes/funcaoId/ajustes` dos usuários e `config.funcoesAcesso`; usuário novo criado por esse caminho entra como vendedora sem permissões personalizadas. Só Diretoria altera função/acesso/loja. Código atual em `db-gateway-v53.ts` (v51/v52 ficam de histórico). OUTRA LOJA (v53): a pessoa escolhe a loja e digita a própria senha; as permissões são as mesmas que ela já tem; fica registrado em `loja_acessos_log` (aprovado por = ela mesma); só o perfil Oficina não vê o cartão.
- 30/out (4): **Auditoria / LOG** (CONFIGURAÇÕES › cartão **LOG**, `log.html`, só Diretoria; `db-gateway` v54, código em `db-gateway-v54.ts`). Tabela `auditoria_log` (RLS, sem GRANT; quem, quando, loja da sessão, `em_outra_loja`, ação, módulo, tabela, registro, resumo, `detalhe` com antes/depois). O gateway grava: login/logout/senha errada, entrada/saída/senha errada de OUTRA LOJA, criar/editar/cancelar/mudar status/excluir (vendas_pdv, ordens_servico, orcamentos, produtos_estoque, clientes_cadastro, gastos, gastos_fixos, dp_*, transferências/reposição/envio, gravacoes_pedidos, marketing_mensagens), movimentos de estoque (`registrarMovimentoEstoque`) e alterações de config (`saveConfig`/`mergeConfigKey`, com diff item a item). Falha ao gravar log nunca derruba a operação. Consulta pela op `auditoriaLista` (filtros, paginação por `antesDe`). **Fora do log (limites):** leituras/consultas, kv de autosave, e gravações feitas direto por outras Edge Functions (insumos-api, inventario-api, reforma-api, atendimento-*, site-admin, lancamentos-api, funcionario-acesso) — para auditar esses módulos, cada função precisa gravar em `auditoria_log` também.
- 30/out (5): **Vendedora travada no login** (Pedido e Venda): para nível vendedora e gerente o campo Vendedora vem preenchido (somente leitura) com o nome do funcionário do login (`vendedoraTravadaNoLogin`); diretoria/oficina continuam escolhendo. **Pedido fora do padrão → solicitar permissão:** no Novo pedido, se a data/vagas fogem do padrão, aparece a tarja vermelha com o motivo e o botão Lançar pedido dá lugar a **Solicitar permissão** + **Tenho o código** (abre o campo do código e volta o Lançar). Solicitar grava em `painel_ordens_kv` chave `autorizacoes` (`{id,lojaId,solicitante,status pendente|liberado|recusado|cancelado,motivo,via{…},codigo,liberadoPor}`); a tela da loja consulta a cada 6 s e, quando liberado, preenche o código sozinha. A Oficina vê balão vermelho no cartão CÓDIGO (o shell consulta a cada 20 s, `verificarAutorizacoes`) e, dentro do cartão, a lista de solicitações → Ver via → **Liberar** (gera o código em `codes`, uso único) ou Recusar. A edição de pedido existente continua só com o campo de código.
- 30/out (6): **Notas fiscais.** `vendas.html`: aba **Com nota** (molde da Sem nota; diretoria/gerente). **Resumo do caixa** (`caixa.html`): botões Mostrar › Resumo / **Sem nota** / **Com nota** (vendas **e** pedidos do período/loja; a lista só carrega ao clicar em Pesquisar) e botão **Fechar caixa**, que lista as pendências do período: venda/pedido pago em Pix/cartão sem nota ("emitir nota fiscal") e marcado com nota sem número ("falta o número da nota"). "Nota emitida"/"Informar nº" grava `emissaoNota:'sim'` + `numeroNota` + `lojaNotaId` (upsert em `vendas_pdv`/`ordens_servico`) e o registro passa sozinho para Com nota. Nas vias de Venda e Pedido (novo e edição) o bloco de pagamento ganhou o botão **Número da nota** (marca Nota fiscal: Sim e guarda `numeroNota`; ao marcar Não, limpa o número). **Data da venda** é fixa (hoje, hora local) no lançamento.
- 30/out (7): **Lote de 2.800 produtos criado direto no banco** (ids `prodest_lote261030_*`; backup completo anterior em `produtos_estoque_backup_lote_20261030`, 491 linhas). Séries `9 F<x> <PEÇA> <METAL>` e `8 F<x> …`, x de 0,1 em 0,1: ALIANÇA até 30,0; ANEL, CORDÃO, PULSEIRA até 10,0; PINGENTE e BRINCO até 5,0; metais OURO 18K e PRATA 925. Categoria da peça (ALIANCA/ANEL/…) + subcategoria OURO/PRATA; fornecedor REPRESENTANTE OURO/PRATA; `fator` = x; `precoVenda` = 2599 × x (ouro), 1050 × x (aliança ouro), 150 × x (prata). Tipo (`tipoVenda`) série 9: aliancaOuro (aliança ouro), joiaRepresentanteOuro (demais ouro), joiaRepresentantePrata (toda prata); série 8: aliancaOuro, joiaVilacaOuro, joiaVilacaPrata. Sem estoque, sem dados fiscais (NCM/CFOP/CST/cClassTrib/origem vazios). `codigoInterno` PRD000498–PRD003297 e `produtosOtica.proximoCodigo` = 3298. **Para desfazer:** `delete from produtos_estoque where id like 'prodest_lote261030_%'` e voltar `proximoCodigo` para 498. Obs.: o "Valor de tabela" que a tela de Cadastro calcula usa Fator › Venda (2.450 joias ouro, com 35% de desconto), não os 2.599 deste lote; a venda usa `precoVenda`.
- 30/out (8): **Produtos além do 1.000º não apareciam** em Venda/Pedido/Orçamento: o servidor (Supabase) devolve no máximo 1000 linhas por chamada e o `selectPage` pedido com `tamanho: 5000` marcava o fim da lista depois da primeira página. Agora os módulos pedem `tamanho: 1000` e paginam (index, vendas, painel-ordens, orcamentos, marketing); **qualquer leitor novo de tabela grande deve paginar de 1000 em 1000**. A busca de produto dos autocompletes (`filtrarProdutosBusca`) ignora acento/maiúscula, aceita palavras em qualquer ordem, procura também no código interno e mostra primeiro quem começa com o texto (até 40 resultados, antes 15).
- 31/out: **Lançamentos por perfil.** Diretoria/gerente: Vendedoras, Lojas, Conferência e Fator completos. Vendedora: lança em Vendedoras e Lojas; Conferência e Fator só para ver (botões de fator ocultos). Oficina: módulo não aparece (padrão `lancamentos.ativo:false`; vendedora passou a `true` em `permissoesPadrao` do index/dp e em `config.funcoesAcesso` fn_vendedora e nos usuários vendedora com permissões salvas; backup `gestao_config` id `backup_perm_lancamentos_20261031`). A aba **Folha de PG foi suprimida** (UI escondida; código e dados da folha ficam guardados). `lancamentos-api` v12 recusa: oficina (403), salvar/excluir de `folha` por qualquer um (403), fator por vendedora (403); vendedora nunca recebe dados de folha.
- 31/out (2): **Cancelamento com destino do valor + CRÉDITO CLIENTE.** Em Vendas saíram do menu "Registrar troca" e "Devolver item" (as funções `abrirTrocaVenda`/`abrirDevolucaoItem` ficam no código sem uso; trocas antigas continuam no Caixa); Pedido não tinha troca. Cancelar venda/pedido **já recebido** (Pix/cartão/dinheiro; crédito e fiado não contam) abre `perguntarDestinoEstorno`: **crédito do cliente** (soma em `cliente.credito`, movimento `tipo:'cancelamento'`, `caixaSaidaCancelamento=0` — o dinheiro fica na loja) ou **devolver** em dinheiro (sai do caixa) / Pix (sai da conta da loja), `caixaSaidaCancelamento = valor`. Gravado em `cancelamentoDestino {tipo,valor}` e mostrado em Caixa › Canceladas. Forma de pagamento **CRÉDITO CLIENTE** (`__credito`) só aparece com cliente selecionado que tenha crédito (`window.__credCli`, evento `credito-cliente`); ao escolher o cliente aparece toast + faixa amarela com o saldo. No Pedido a forma só é oferecida no pedido novo (edição de pedido não processa uso de crédito). Cancelar com crédito exige cliente no cadastro.
- 31/out (3): **Fechamento do caixa do dia.** Resumo do caixa › Fechar caixa: com **um dia e uma loja** nos filtros e sem pendências de nota, o botão **Fechar caixa do dia** grava `painel_ordens_kv` chave `caixa_fech:<lojaId>:<AAAA-MM-DD>` `{fechado,por,em,historico}`; qualquer perfil com o módulo `caixa` (inclusive vendedora) fecha. **Reabrir caixa** só gerente/diretoria (guarda quem fechou/reabriu em `historico`). Com o caixa de hoje fechado, Vendas e Pedido recusam lançar venda/pedido e cancelar (checagem no front: `bloqueadoPorCaixaFechado`); Gastos, edição de venda/pedido e outros módulos **não** são travados. Vendedora já via todas as vendas da própria loja na lista Lançadas (o servidor filtra por `users[].lojas`).
- 31/out (4): **Botão Cancelar ao lado de Salvar** (Vendas: antes de "Lançar venda"; Pedido: antes de "Salvar rascunho") no lugar do balão × flutuante (continua igual no Orçamento). **Pedido: cada item escolhe Produto ou Serviço** (`it.tipoItem`, só de tela) e a busca lista só o tipo escolhido (serviço abre a lista inteira ao clicar); serviço = categoria SERVIÇO/SERVICO ou `tipo` "Serviço" (`produtoEhServico`). **Cadastro › Produto › Fiscal**: categoria SERVIÇO (`ehCategoriaServico`) troca NCM/CFOP/ICMS/origem/GTIN por `produto.servicoFiscal {itemLC116, codTribNacional, codTribMunicipal, nbs, cnae, aliquotaIss, issRetido, exigibilidadeIss}` + CST IBS/CBS e cClassTrib; nada emite nota, valores a confirmar com o contador. Os 2 cadastros de categoria (SERVIÇO e SERVICO) valem como serviço.
- 31/out (5): **Solicitar permissão agora LANÇA o pedido** (`lancarPedido`, `pendenciaReq`): o pedido nasce com `autorizacao {status:'pendente', solicitacaoId, dataSolicitada, motivo}` e a solicitação (com `ordemId`) vai para `painel_ordens_kv`/`autorizacoes` como antes, para a Oficina ver a via completa. Na lista do Pedido a marca é **vermelha** "Pendência de autorização"; a Oficina **libera** (sem gerar código) → **verde** "Encaixe autorizado por X" (`encaixe=true`, `autorizadoPor`) ou **recusa** → **amarela** "Autorização recusada · data ajustada" (data volta para `proximaDataDisponivel`, `autorizacao.dataAnterior/motivoRecusa`). Como a Oficina não tem lojas e não grava `ordens_servico`, quem aplica a resposta no pedido é a tela da loja: `sincronizarAutorizacoesPendentes` (ao abrir e a cada 20 s). "Tenho o código" continua valendo e lança como encaixe normal. Pedidos antigos sem `autorizacao` seguem com o selo "Encaixe".
- 28/out: RLS ligado em `atendimento_pessoal_usuarios`, `atendimento_lembretes` e `atendimento_setup_log` (só Edge Functions com service_role usam).

---

## 16. Módulo Reforma (v2 — 25/set/2026)

Fluxo v2: cliente abre `https://vilaca-controle-lojas.vercel.app/reforma.html` → escolhe **entrega** (leva na loja / envia pelos Correios) e **devolução** (retira na loja / recebe pelos Correios — pede CEP e, se for essa a devolução, endereço completo via ViaCEP) → adiciona **até 10 itens**, cada um com serviço, descrição, peso opcional, observação e 1-6 fotos → pedido entra na fila do módulo **Reforma** (menu 💍) → vendedora orça **peça por peça** (valor, obs pública, obs interna, "inviável") e, se envolver Correios, calcula/edita o **frete** (ida informativa + volta cobrada, com "frete grátis" manual ou por regra `gratisAcima`, e "reembolsar envio do cliente") → WhatsApp (mensagem pronta: **"Enviar pelo sistema"** via Evolution API, registrado no módulo Atendimento, ou **"Abrir no meu WhatsApp"** via `wa.me`) → cliente aprova **item a item** pelo link (ou "Aceite presencial") → **check-in de custódia** com peso, teor, lacre e **foto obrigatória de cada peça aprovada** (+ fotos do pacote se veio pelos Correios) → **Gerar O.S.** → **check-out** com peso e **foto obrigatória de cada peça** → se devolução for Correios: **postar** (rastreio + foto do comprovante, status vira `enviado`) → **entregar** (assinatura). Recibo de custódia imprimível com uma linha por peça.

Modelo de dados (`reforma_pedidos.payload`):
- `itens[]`: `{id, descricao, servico, servicoNome, pesoInformado, obsCliente, fotos[], orcamento:{valor,obsPublica,obsInterna,inviavel}, aprovado, custodia:{entrada:{peso,teor,teorObs,lacre,observacoes,fotos},saida:{peso,lacre,observacoes,fotos}}}`
- `entrega:{modo:'loja'|'correios', lojaId}`, `devolucao:{modo:'retirar'|'correios', lojaId}`, `endereco:{cep,logradouro,numero,complemento,bairro,cidade,uf}` (só preenchido se algum modo usa Correios)
- `orcamento.frete:{ida,volta:{servico,valor,prazo,origem}, gratis, reembolsarIda, gratisAcima}` — `origem` é `'correios'`, `'tabela'` ou `'manual'`
- `aceite:{em,modo,itens[],totais}`; `custodia:{entrada,fotosPacote,saida,entrega}`; `postagem:{rastreio,servico,valorPago,fotos,em}`
- Totais (`calcularTotais` no backend e replicado no front): `total = subtotal dos itens aprovados + frete de volta cobrado (se Correios e não grátis) − reembolso do frete de ida (se marcado)`; frete grátis = manual OU `subtotal ≥ frete.gratisAcima`; custo que a loja absorve vai só para `infoInterna` da O.S., nunca no total cobrado do cliente
- Pedidos da v1 (um item só) são convertidos em memória por `normalizar()` ao abrir (`it_legado`) — não precisa migração de dados

Frete (`reforma_config` id=`config`, chave `frete`):
- `provider`: `'tabela'` (padrão — valores fixos por faixa mesmaUf/sudeste/brasil × SEDEX/PAC, editável em Configurações) ou `'correios'` (API oficial)
- Se `provider:'correios'` e a chamada falhar, cai automaticamente na tabela e devolve `aviso` — nunca trava o orçamento
- Credenciais dos Correios ficam em `reforma_config` id=**`segredos`** (nunca voltam para o front — `init` só devolve `segredosStatus:{correios:boolean}`): `correiosUsuario`, `correiosCodigoAcesso` (gerado em cws.correios.com.br → Gestão de acesso a API's — **não é a senha do Meu Correios**, e regerar invalida qualquer outro sistema que já use esse código), `correiosCartao` (número do cartão de postagem do contrato)
- Endpoints usados: token `POST /token/v1/autentica/cartaopostagem`, preço `GET /preco/v1/nacional/{cod}`, prazo `GET /prazo/v1/nacional/{cod}` (`api.correios.com.br`, códigos padrão SEDEX `03220` / PAC `03298`)
- Felipe tem contrato próprio (confirmado 25/set) mas pediu para não configurar ainda — módulo segue com `provider:'tabela'`

WhatsApp: usa os **mesmos segredos do módulo Atendimento** (`atendimento_segredos`: `EVOLUTION_URL`, `EVOLUTION_API_KEY`; instância padrão configurável em `reforma_config.whatsappInstancia`, senão primeira instância não-Instagram de `config.atendimentoInstancias`, senão `'reformajoias'`). Envio pelo sistema cria/atualiza a conversa em `atendimento_conversas`/`atendimento_mensagens` — aparece também no módulo Atendimento. Templates com placeholders `{cliente} {codigo} {itens} {valor} {frete} {prazo} {validade} {link} {loja} {endereco} {entrega} {devolucao} {rastreio}`.

Regras que continuam da v1:
- **A O.S. é criada direto na tabela `ordens_servico`** pela `reforma-api` (op `gerarOS`), no mesmo formato do painel-ordens: `codigoVia` via rpc `incrementar_via_sequence` (`codigo_${ABREV}_pedido` → ex. `MC12P`), `status:'aguardando'`, `momentoPagamento:'na_volta'`, `pagamentos:[]`, **um item de O.S. por peça aprovada** + linha `FRETE RETORNO CORREIOS` (se cobrado) + linha negativa `REEMBOLSO ENVIO DO CLIENTE` (se marcado), fotos com `driveUrl` = signed URL de 10 anos. Marcadores: `origem:'reforma'`, `reformaId`, `reformaCodigo`. **painel-ordens.html não foi alterado** — não recriar essa conversão lá.
- Cliente sem cadastro entra em `clientes_cadastro` (busca pelo telefone antes de inserir; nunca duplica).
- Sessão: mesma regra do db-gateway (`sessaoValida` copiada). Permissão: `permissoes.reforma.ativo`; padrão diretoria/gerente/vendedora = true, oficina = false. Vendedora só vê pedidos das lojas dela (`user.lojas`).
- Ops públicas (`publicInit`, `publicCriar`, `publicConsultar`, `publicAceitar`) não têm sessão: rate limit 5 pedidos/telefone/24h e 25/IP/24h; a visão pública nunca inclui observações internas.
- Numeração do pedido: `R` + `numero` (bigserial) com 5 dígitos (`R00012`). Status: `novo` → `orcado` → `aprovado`/`recusado` → `em_custodia` → `os_gerada` → `pronto` → (`enviado`, só se devolução for Correios) → `entregue` (ou `cancelado`; `expirado` é calculado quando `validadeAte` passou).
- Shell/DP: acréscimos únicos foram `{ id:'reforma', label:'Reforma', icon:'💍', src:'reforma-admin.html' }` em `SIDEBAR_MODULES`, `reforma` em `MODULOS_APP` e `reforma:{ ativo:true|false }` nos três blocos de `permissoesPadrao` (index.html e dp.html). Nada disso mudou na v2 — v2 foi só `reforma-api`, `reforma.html` e `reforma-admin.html`.

---

## 17. Ambiente de TREINO/TESTE (4/nov/2026)

Um só código (mesmo repo, mesmo projeto Vercel `vilaca-controle-lojas`), três endereços. O banco é escolhido pelo endereço em `supabase-config.js`:

- `vilaca.app` (e `www`) → banco REAL `wxiokmqnjtgbejgoepch`. Nada mudou.
- `treino.vilaca.app` e `teste.vilaca.app` → banco de TESTE `mpgkvstzigeaimuynpxc` (projeto "VILACA TESTE", organização grátis "VILACA TESTE", região us-west-2, custo zero). Faixa fixa no rodapé (verde = TREINAMENTO, marrom = TESTE). Qualquer host `teste.*`, `treino.*` ou `*-teste.*` cai no teste.
- DNS: `vilaca.app` está no DNS da Vercel com `*` ALIAS; subdomínio novo só precisa ser adicionado ao projeto (`add_project_domain`), sem mexer em DNS.

Regras de código para TODA edição futura:
- Tela nova nunca escreve URL/chave do Supabase fixa: usar `window.SUPABASE_URL` / `window.SUPABASE_ANON_KEY`. Link que vai para o cliente usa `window.APP_URL` (real = `https://vilaca.app`; treino/teste = o próprio endereço).
- `index.html` desliga `atendimento`, `site`, `ia` e `reforma` fora da produção (`MODULOS_DESLIGADOS_FORA_DA_PRODUCAO`, dentro de `permissoesDoUsuario`). Nada do treino pode falar com o mundo de fora (WhatsApp, e-mail, Drive, IA).
- A chave anon do teste fica no `supabase-config.js` (pública por natureza, como a do real). Ao digitar chave nova: provar contra o servidor (pg_net) e comparar sha256 — chave errada derruba o login do endereço.

Banco de teste:
- Mesmas tabelas, funções e gatilhos do real + 15 edge functions: `db-gateway`, `trocar-usuario`, `autorizar-gestor`, `entrar-como`, `meus-dados`, `termos-uso`, `funcionario-acesso` (link de convite aponta para o treino), `estoque-api`, `caixa-resumo` (sem WhatsApp: devolve `desligado`), `retirada-terceiro`, `reservas-api`, `agenda-tarefas`, `lancamentos-api`, `inventario-api`, `insumos-api`.
- NÃO publicadas no teste de propósito (falam com o exterior ou são de outros apps): `send-email-gmail`, `upload-foto-drive`, `backup-*`, `atendimento-*`, `ia-chat`, `gemini-agente`, `reforma-api`, `site-*`, `crm-api`, `cotacoes-mercado`, `bi4cia-*`, `confirmar-leitura-*`. Chamar uma delas no teste dá 404 (inofensivo).
- Dados: cópia ANONIMIZADA (clientes com nome, telefone e CPF inventados; produtos e estoque reais; configuração com as lojas + a loja `loja_tr` TREINAMENTO). A função `treino-export` no REAL só entrega dado já anonimizado, protegida por chave (no real fica só o hash); o teste puxa por pg_net.
- Logins de treino: `TREINO GERENTE`, `TREINO VENDEDORA 1`, `TREINO VENDEDORA 2` (loja TREINAMENTO) e `TREINO OFICINA` (loja OFICINA). A senha combinada com o Felipe não fica neste arquivo (repo público). O primeiro acesso com senha padrão foi desligado (seção 18): quem estiver sem senha no teste recebe a senha inicial da diretoria no DP.
- Mudou função ou tabela no REAL? Repetir no TESTE (mesmo código; a única diferença é o `APP_BASE_URL` da `funcionario-acesso`).

Manutenção:
- Projeto grátis pausa após ~7 dias sem uso. O pg_cron do REAL tem o job `treino-mantem-acordado` (todo dia 09:23 UTC) que dá um toque no `db-gateway` do teste. Se pausar mesmo assim: `restore_project` pelo conector "Supabase Teste".
- O conector MCP "Supabase Teste" é separado do "Supabase" (real): uma organização por conector.

## 18. Versão de 4/nov/2026 (testada no branch `teste`, publicada no real no mesmo dia)

Fluxo: mudança grande vai primeiro para o branch `teste` → `teste.vilaca.app` (banco de TESTE). `treino.vilaca.app` segue o `main` (mesmo banco de teste). Só depois do OK do Felipe: passos do REAL abaixo + merge no `main`.
- `teste.vilaca.app` está no projeto como domínio de produção (sem branch), então é apontado por ALIAS para o último deploy do branch `teste` (`assign_alias` do conector Vercel). A cada envio ao branch `teste`: esperar o deploy ficar READY e refazer o alias. Todo deploy do `main` devolve o domínio ao `main`. Para prender de vez ao branch é no painel da Vercel (Settings › Domains › teste.vilaca.app › Git Branch = `teste`), que precisa do login do Felipe.

O que entrou (pedido do Felipe, 04/11):
- LINK ECO: forma de pagamento que funciona como cartão (+20%, até 12x; `cartao:true`) e exige NF no fechamento do caixa (`exigeNota:true`), com a nota pela VILAÇA ECOMMERCE (`lojaNotaId`). Config › Pagamento tem o botão "Adicionar LINK ECO" e essas opções por forma.
- Vendedora = gerente, só nas lojas dela (no DP continua vendo só o dela: `soProprioDP`). O padrão está em `permissoesPadrao` (index.html e dp.html — manter as duas cópias iguais). Quem tem `permissoes` gravadas segue o gravado: nos dados, a função Vendedora precisa ficar igual à Gerente (DP › Funções).
- Editar venda/pedido abre a via em tela cheia (`#modalOverlay.tela-cheia`), sem popup; salva no fim.
- Reserva aceita relógio (`produtoReservavel` no vendas.html; `reservas-api`).
- Oficina lê com o leitor as vias de JV/Vilaça: o shell manda a oficina direto para o Pedido; `buscarPorCodigoVia` não filtra loja para a oficina; botão RECEBIDO também em 'aguardando' (Insumos).
- Senha: acabou o "primeiro acesso 123456". A diretoria cria a senha inicial ao criar o acesso (DP); quem não tem senha recebe `semSenha` no login. O Termo de Uso segue obrigatório em todo login até ser aceito (`exigirTermos`).
- Vendedora e gerente mudam qualquer status e editam (painel-ordens `statusPermitidos`).
- Via "pagar depois": dá para incluir pagamento na edição; ele entra no caixa do dia em que foi feito (o caixa conta recebimento pela data do pagamento: `recebidoNoPeriodo`).
- Ideias aprovadas: Kanban de pedidos (Lista/Quadro; arrastar muda o status), busca geral no topo (botão ou tecla "/", op `buscaGeral`), Dashboard › "Custo e margem" (só diretoria), login e sessões gravados de forma atômica.

Servidor (banco de TESTE):
- Funções SQL `cfg_sessao_abrir`, `cfg_login_falhou`, `cfg_sessao_fechar`, `cfg_sessao_loja_extra`, `cfg_usuario_patch`, `cfg_salvar`, `cfg_set_chave` (+ `_agora_ms`, `_cfg_user_idx`, `_sessoes_vivas`): SECURITY DEFINER, execução só para service_role. Gravam só o pedaço que mudou do `gestao_config`, com trava de linha — login, logout e salvar configuração não apagam mais a sessão de outra pessoa. Foram criadas por SQL direto (não estão em migration): para levar ao real, copiar com `pg_get_functiondef`.
- `db-gateway` v64 usa as `cfg_*`, tem `buscaGeral`, devolve `semSenha`, aceita `senhaInicial` em usuário novo e desliga `primeiroAcesso`. `termos-uso` e `entrar-como` gravam via `cfg_usuario_patch`. `agenda-tarefas`, `insumos-api`, `lancamentos-api`, `inventario-api`: vendedora = gerente nas lojas dela. `funcionario-acesso`: senha definida pela diretoria encerra o primeiro acesso antigo (ainda grava a configuração inteira; trocar por `cfg_usuario_patch` numa próxima).

Publicado no REAL em 04/11/2026 (nesta ordem — servidor antes da tela; repetir a ordem nas próximas):
1. Migration `cfg_funcoes_atomicas` (funções `cfg_*` idênticas às do teste, conferidas por md5 do `pg_get_functiondef`).
2. Edge functions: `db-gateway` v65, `termos-uso` v5, `entrar-como` v2, `funcionario-acesso` v29 (`APP_BASE_URL = https://vilaca.app`), `insumos-api` v10, `inventario-api` v7, `lancamentos-api` v21, `reservas-api` v3, `agenda-tarefas` v5.
3. Merge `teste` → `main`.
4. Dados: forma LINK ECO (`cartao`, `exigeNota`, `lojaNotaId = loja_ec`) e função Vendedora = Gerente (vendedoras com permissões gravadas recalculadas). Ninguém estava no primeiro acesso antigo.

Lição (deploy de edge function pelo conector): a camada de ferramentas troca `\u` + 4 dígitos hex pelo caractere de verdade antes de enviar (ex.: regex `[\u0300-\u036f]` vira acentos soltos). Funciona igual, mas o arquivo publicado não fica idêntico ao do repositório. Ao publicar arquivo com esse tipo de escape, mandar a barra como `\u005c` no JSON e conferir depois com `get_edge_function` + `diff`.

## 19. Ouro, nota de entrada, campos em vermelho e login do teste (04/11)
- `vilaca-extras.js` (novo, carregado em vendas, painel-ordens, orcamentos, caixa): `Destaque.marcar(alvos, msg)` pinta o campo faltando/errado de vermelho (classe `.v-erro`), rola e foca; `OuroPag` cuida do ouro.
- Ouro maior que a compra: a sobra vira CRÉDITO do cliente (`creditoGerado` na via; cliente precisa estar cadastrado). A linha do ouro é gravada só com o valor da compra (`valorEntregue` guarda o que o cliente trouxe) para o caixa/relatórios baterem. Cancelar/editar a via desfaz o crédito (tira só o que o cliente ainda tem). Só o ouro pode passar do total.
- Nota de ENTRADA (via com ouro): botão Emitir obrigatório + nº opcional (`notaEntrada {emitida, numero}`); o fechamento do caixa (caixa.html) exige o número.
- `login-teste` (função só no banco de teste; recusa se o projeto não for o de teste): em teste.vilaca.app o login mostra Oficina/Vendedora/Gerente sem senha; Diretoria pede a senha (definida no banco de teste, não está no repositório). Não existe em produção nem no treino.
- 04/11: pagar depois = nota "não" (criação e edição); o Caixa não cobra nota de via "pagar depois" sem pagamento e respeita o "não" escolhido na via (só LINK ECO sempre exige). Todo login entra na primeira loja do cadastro da pessoa (seletor troca depois).
